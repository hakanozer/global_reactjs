import React, { useEffect, useState } from 'react';
import NavMenu from '../components/NavMenu';

function Dashboard() {

  // Create Ref
  const txtRef = React.createRef()

  const [name, setName] = useState("")
  const [number, setNumber] = useState(0)
  const [search, setSearch] = useState("")

  function fncSend( number ) {
    console.log('name', (name + " " + number ) )
    setName("")
    txtRef.current.focus()
    txtRef.current.style.backgroundColor = "red";
  }

  // ArrowFnc
  const sum = (num1, num2) => {
    const sm = num1 + num2
    console.log('sm', sm)
    setNumber(sm)
  }
  
  useEffect(() => {
    sum(40,50)
  }, [])

  const data = [
    { name: "Ali", surname: "Bilmem" },
    { name: "Veli", surname: "Bilmem" },
    { name: "Hasan", surname: "Bilmem" },
    { name: "Zehra", surname: "Bilmem" },
    { name: "Ali-1", surname: "Bilmem" },
    { name: "Ali-2", surname: "Bilmem" },
    { name: "Ali-3", surname: "Bilmem" },
  ]

  const fncPrint = () => {
    console.log('fncPrint Call')
  }

  return (
    <React.Fragment>
        <NavMenu btnClick={fncPrint}  setName={setSearch} />
        <br></br>
        <input ref={txtRef} value={name} className="form-control" onChange={ (evt) => setName(evt.target.value) } type="text" /><br></br>
        <input className="btn btn-danger" onClick={ () => fncSend(10) } type="button" value="Send"></input>
        <h3> {name} </h3>
        <h3> {search} </h3>
        <h4> Sum : { number } </h4>
        { data.map( (item, index)  => {
          return (
            <div key={index} > 
              <div>{ item.name } - { item.surname }</div> 
            </div>
          )
        })}
    </React.Fragment>
  );
}

export default Dashboard;
