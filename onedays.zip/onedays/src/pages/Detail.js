import React from 'react'
import { useParams } from 'react-router-dom'
import NavMenu from '../components/NavMenu'

function Detail( props ) {

    const { pid, title } = useParams()
    console.log('props', props)
    const paramsUrl = props.location.search
    const query = new URLSearchParams(paramsUrl)
    const pidx = query.get("pid")


    return (
        <div>
            <NavMenu />
            <h1>Welcome Detail</h1>
            <h3> {pid} </h3>
            <h3> {title} </h3>
            <h4> { pidx } </h4>
        </div>
    )
}

export default Detail
