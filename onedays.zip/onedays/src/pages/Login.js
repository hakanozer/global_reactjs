import React from 'react'

function Login() {
    return (
        <h1> Welcome Login </h1>
    )
}

export default Login
