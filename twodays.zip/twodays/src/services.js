import Axios from 'axios'
import { baseURL, timeout } from './AppSettings'

const aObj = Axios.create({
    baseURL: baseURL,
    timeout: timeout,
    headers: null
})

export const userLogin = async ( params ) => {
    return await aObj.get("userLogin.php", { params: params })
}

export const product = async ( params ) => {
    return await aObj.get("product.php", { params: params })
}
