import { Base64 } from 'js-base64'
import React, { useEffect, useState } from 'react'
import { Button, Form, FormControl, Nav, Navbar, NavDropdown } from 'react-bootstrap'
import { Redirect } from 'react-router-dom'

function NavMenu() {

    const [loginStatu, setLoginStatu] = useState(false)
    const [nameSurname, setNameSurname] = useState("")

    useEffect(() => {
        
        // localStorge control
        const localUser = localStorage.getItem("user")
        if ( localUser != null ) {
            sessionStorage.setItem("user", localUser )
        }

        // session control
        const sessionUser = sessionStorage.getItem("user")
        if ( sessionUser ==  null ) {
            setLoginStatu(true)
        }else  {
            // server services control
            const cString = Base64.decode(sessionUser)
            const cJson = JSON.parse(cString)
            const n = cJson.userName + " " + cJson.userSurname
            setNameSurname(n)
        }

    }, [])

    // logout Fnc
    function fncLogout() {

        const answer = window.confirm("Are you sure?")
        if ( answer ) {
            // session clear
            sessionStorage.removeItem("user")
            sessionStorage.clear()

            // local clear
            localStorage.clear()
            setLoginStatu(true)
        }

    }

    return (
        <Navbar bg="light" expand="lg">
            { loginStatu && <Redirect to="/" ></Redirect> }
            <Navbar.Brand href="/dashboard">Admin Control</Navbar.Brand>
            <Navbar.Toggle aria-controls="basic-navbar-nav" />
            <Navbar.Collapse id="basic-navbar-nav">
                <Nav className="mr-auto">
                    <Nav.Link href="/dashboard">Dashboard</Nav.Link>
                    <Nav.Link href="/link">Link</Nav.Link>
                    <NavDropdown title="Dropdown" id="basic-nav-dropdown">
                        <NavDropdown.Item href="#action/3.1">Action</NavDropdown.Item>
                        <NavDropdown.Item href="#action/3.2">Another action</NavDropdown.Item>
                        <NavDropdown.Item href="#action/3.3">Something</NavDropdown.Item>
                        <NavDropdown.Divider />
                        <NavDropdown.Item onClick={ fncLogout }>Logout</NavDropdown.Item>
                    </NavDropdown>
                    <Nav.Link>{nameSurname}</Nav.Link>
                </Nav>
                <Form inline>
                    <FormControl type="text" placeholder="Search" className="mr-sm-2" />
                    <Button variant="outline-success">Search</Button>
                </Form>
            </Navbar.Collapse>
        </Navbar>
    )
}

export default NavMenu
