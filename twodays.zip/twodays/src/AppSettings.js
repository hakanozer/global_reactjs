export const baseURL = "http://jsonbulut.com/json/"
export const timeout = 30000