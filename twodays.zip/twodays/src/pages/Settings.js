import React, { useEffect } from 'react'
import { Button, Col, Container, Form } from 'react-bootstrap'
import NavMenu from '../components/NavMenu'
import $ from 'jquery'
import SettingForm from '../components/SettingForm'

function Settings() {

    useEffect(() => {
        $("#loginForm").slideToggle()
    }, [])

    
    function btnClick() {
        const h = $("#txtName").outerHeight()
        const name = $("#txtName").val()
        if (name === "") {
            $("#txtName").animate({ height: 0 }, 200, function() {
                $(this).animate({ height: h}, 300 )
                $(this).focus()
            })
        }
    }

    return (
        <Container>
            <NavMenu />
            <hr></hr>
            <Form id="loginForm" style={{ display:"none" }}>
                <Form.Row>
                    <Col>
                    <Form.Control id="txtName" placeholder="First name" />
                    </Col>
                    <Col>
                    <Form.Control placeholder="Last name" />
                    </Col>
                </Form.Row>
            </Form><br></br>
            <Button onClick={btnClick} variant="danger"> Open Slide </Button>
            <SettingForm />
        </Container>
    )
}

export default Settings
