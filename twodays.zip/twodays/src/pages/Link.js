import React, { useEffect, useState } from 'react'
import { Button, Container, Form } from 'react-bootstrap'
import { Helmet } from 'react-helmet'
import NavMenu from '../components/NavMenu'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faPaperPlane } from '@fortawesome/free-solid-svg-icons'

import { connect } from 'react-redux'
import { action_product_add }  from '../actions/ProductAction'
import { productReducer } from '../reducers/ProductReducer'

function Link( props ) {

    const [name, setName] = useState("")
    const [surname, setSurname] = useState("")

    useEffect(() => {
        console.log('useEffect -1', "Call")
        return () => {
            call()
        }
    }, [surname])


    useEffect(() => {
        console.log('useEffect -2', "Call")
    }, [])


    function call() {
        console.log('call')
    }

    function productAdd() {
        props.itemAdd( { name: name, surname: surname  } )
    }


    return (
        <Container>
            <Helmet>
                <title>Link Title</title>
            </Helmet>
            <NavMenu />

            <Form.Group controlId="name">
                <Form.Label>Name</Form.Label>
                <Form.Control onChange={ (evt) => setName( evt.target.value ) } type="text" placeholder="Name"></Form.Control>
            </Form.Group>

            <Form.Group controlId="surname">
                <Form.Label>Surname</Form.Label>
                <Form.Control onChange={ (evt) => setSurname( evt.target.value ) } type="text" placeholder="Surname"></Form.Control>
            </Form.Group>

            <div> { name } { surname } </div>

            <Button onClick={ productAdd } variant="danger"> <FontAwesomeIcon size="1x" icon={faPaperPlane} /> Send </Button>
            
            { props.productReducer.map( (item, index) => {
                return (
                    <div key={index}> {item.name} {item.surname} </div>
                )
            })}

        </Container>
    )
}

const mapStateToProps = ( state ) => ({
    productReducer: state.productReducer.products
})

const mapDispatchToProps = ( dispatch ) => {
    return {
        itemAdd: item => {
            dispatch(action_product_add(item))
        }
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Link)
