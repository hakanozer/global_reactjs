import React from 'react'
import { Container } from 'react-bootstrap'
import NavMenu from '../components/NavMenu'

function Dashboard() {
    return (
        <Container>
            <NavMenu />
            <h1>Welcome Dashboard</h1>
        </Container>
    )
}

export default Dashboard
