import React from 'react';
import ReactDOM from 'react-dom';
import * as serviceWorker from './serviceWorker';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter as Router, Route } from 'react-router-dom'

// Import Pages
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';


const routerObj = 
<Router>
  <Route exact path="/" component={Login} ></Route>
  <Route path="/dashboard" component={Dashboard} ></Route>
</Router>


ReactDOM.render( routerObj, document.getElementById('root'));
serviceWorker.unregister();
