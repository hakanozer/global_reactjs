import React from 'react';
import ReactDOM from 'react-dom';
import * as serviceWorker from './serviceWorker';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter as Router, Route } from 'react-router-dom'

import { Provider } from 'react-redux'
import Store from './Store'



// Import Pages
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Link from './pages/Link';
import Settings from './pages/Settings';


const routerObj = 
<Router>
  <Route exact path="/" component={Login} ></Route>
  <Route path="/dashboard" component={Dashboard} ></Route>
  <Route path="/link" component={Link} ></Route>
  <Route path="/settings" component={Settings}></Route>
</Router>

if ("serviceWorker" in navigator) {
  navigator.serviceWorker
    .register("./firebase-messaging-sw.js")
    .then(function(registration) {
      console.log("Registration successful, scope is:", registration.scope);
    })
    .catch(function(err) {
      console.log("Service worker registration failed, error:", err);
    });
}


ReactDOM.render( <Provider store={Store}> { routerObj } </Provider>, document.getElementById('root'));
serviceWorker.unregister();
